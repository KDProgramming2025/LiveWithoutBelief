import { FastifyInstance } from 'fastify';

declare function buildServer(): FastifyInstance;

export { buildServer };
